# RK AI (Kotlin + Jetpack Compose)

## Get the APK with no PC (GitHub, ~5 min, free)
1. Create a free account at github.com, tap "New repository", name it RKAI.
2. Upload ALL files from this project (keep the folder structure, including the hidden `.github` folder).
   Easiest: on a computer, drag the unzipped folder contents into the repo's "Upload files" page.
3. Open the repo > Actions tab > "Build APK" > Run workflow (it also runs automatically on upload).
4. When it turns green, open the run > Artifacts > download "RK-AI-debug-apk" (a zip containing app-debug.apk).
5. Unzip, copy app-debug.apk to your phone, tap it, allow "Install unknown apps" when asked.

## Or build with Android Studio
Open this folder in Android Studio (Koala or newer), let Gradle sync, then Build > Build APK(s).
APK path: app/build/outputs/apk/debug/app-debug.apk

## First run
1. CONFIG tab: paste a Gemini API key (https://aistudio.google.com/apikey), tap SAVE.
2. Tap the mic and allow microphone access.
3. Try: "open WhatsApp", "play Believer on YouTube", "what's up RK?"
4. Optional: CONFIG > Open Accessibility Settings > RK AI Automation > turn on.
   Then: "scroll down", "go back", "tap Subscribe". If blocked: Settings > Apps > RK AI > ⋮ > Allow restricted settings.
