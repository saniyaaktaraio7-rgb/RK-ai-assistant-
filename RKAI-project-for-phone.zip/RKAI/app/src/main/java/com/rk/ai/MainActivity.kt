package com.rk.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RkTheme {
                val vm: RkViewModel = viewModel()
                RkApp(vm)
            }
        }
    }
}

@Composable
fun RkApp(vm: RkViewModel) {
    var tab by remember { mutableStateOf(0) }
    val icons = listOf("◉", "</>", "⚙")
    val labels = listOf("CHAT", "CODE", "CONFIG")
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                labels.forEachIndexed { i, l ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(icons[i], color = Cyan, fontSize = 18.sp) },
                        label = { Text(l, color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp) },
                        colors = NavigationBarItemDefaults.colors(indicatorColor = Cyan.copy(alpha = 0.18f))
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> ChatScreen(vm, false)
                1 -> ChatScreen(vm, true)
                else -> SettingsScreen(vm)
            }
        }
    }
}

@Composable
fun ArcReactor(active: Boolean, dia: Dp = 64.dp) {
    val t = rememberInfiniteTransition(label = "reactor")
    val rot by t.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (active) 1800 else 8000, easing = LinearEasing)),
        label = "rot"
    )
    val pulse by t.animateFloat(
        initialValue = 0.5f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "pulse"
    )
    Canvas(Modifier.size(dia)) {
        val r = this.size.minDimension / 2f
        val c = center
        drawCircle(Cyan.copy(alpha = 0.12f * pulse), r)
        drawCircle(Cyan, r * 0.96f, style = Stroke(2.dp.toPx()))
        rotate(rot) {
            for (i in 0 until 3) drawArc(
                Cyan, i * 120f, 70f, false,
                topLeft = Offset(c.x - r * 0.78f, c.y - r * 0.78f),
                size = Size(r * 1.56f, r * 1.56f),
                style = Stroke(4.dp.toPx(), cap = StrokeCap.Round)
            )
        }
        rotate(-rot * 1.6f) {
            for (i in 0 until 4) drawArc(
                Amber.copy(alpha = 0.8f), i * 90f, 40f, false,
                topLeft = Offset(c.x - r * 0.55f, c.y - r * 0.55f),
                size = Size(r * 1.1f, r * 1.1f),
                style = Stroke(2.dp.toPx(), cap = StrokeCap.Round)
            )
        }
        drawCircle(Cyan.copy(alpha = pulse), r * 0.22f)
    }
}

@Composable
fun Bubble(m: ChatMessage, codeMode: Boolean) {
    val clip = LocalClipboardManager.current
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (m.fromUser) Alignment.End else Alignment.Start) {
        Box(
            Modifier
                .widthIn(max = 330.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (m.fromUser) Cyan.copy(alpha = 0.12f) else Panel)
                .border(1.dp, if (m.fromUser) Cyan.copy(alpha = 0.5f) else CyanDim, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            SelectionContainer {
                Text(
                    m.text, color = TextMain, fontSize = if (codeMode && !m.fromUser) 13.sp else 15.sp,
                    fontFamily = if (codeMode && !m.fromUser) FontFamily.Monospace else FontFamily.Default
                )
            }
        }
        if (codeMode && !m.fromUser) {
            TextButton(onClick = { clip.setText(AnnotatedString(m.text)) }) { Text("COPY", color = Cyan, fontSize = 12.sp) }
        }
    }
}

@Composable
fun ChatScreen(vm: RkViewModel, codeMode: Boolean) {
    val msgs = if (codeMode) vm.code else vm.chat
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startListening(codeMode)
    }
    LaunchedEffect(msgs.size, vm.busy) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1)
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            ArcReactor(active = vm.busy || vm.listening)
            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                Text(if (codeMode) "RK // CODE CORE" else "R.K.  A.I.", color = Cyan, fontSize = 20.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("STATUS: ${vm.statusText}", color = CyanDim, fontSize = 11.sp, letterSpacing = 2.sp)
            }
            TextButton(onClick = { vm.clear(codeMode) }) { Text("CLEAR", color = CyanDim, fontSize = 11.sp) }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), state = listState,
            contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (msgs.isEmpty()) item {
                Text(
                    if (codeMode) "Paste an error, describe a feature, or ask for code in any language."
                    else "Hey, I'm RK. Try: \"open Spotify\", \"play Believer on YouTube\", or just talk to me.",
                    color = CyanDim, fontSize = 14.sp
                )
            }
            items(msgs) { Bubble(it, codeMode) }
            if (vm.busy) item { Text("processing…", color = CyanDim, fontSize = 13.sp) }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (codeMode) "Ask RK to code…" else "Talk to RK…", color = CyanDim) },
                colors = fieldColors(), shape = RoundedCornerShape(24.dp), maxLines = 4
            )
            Spacer(Modifier.size(8.dp))
            Button(
                onClick = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                        vm.startListening(codeMode)
                    else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (vm.listening) Amber else Cyan.copy(alpha = 0.2f))
            ) { Text("🎙", fontSize = 20.sp) }
            Spacer(Modifier.size(6.dp))
            Button(
                onClick = { vm.send(input, codeMode); input = "" },
                shape = CircleShape, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Cyan)
            ) { Text("➤", fontSize = 18.sp, color = Bg) }
        }
    }
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Cyan, unfocusedBorderColor = CyanDim,
    focusedTextColor = TextMain, unfocusedTextColor = TextMain, cursorColor = Cyan,
    focusedLabelColor = Cyan, unfocusedLabelColor = CyanDim
)

fun isA11yEnabled(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
    return s.contains(ctx.packageName) && s.contains("RkAccessibilityService")
}

@Composable
fun SettingsScreen(vm: RkViewModel) {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(vm.prefs.apiKey) }
    var model by remember { mutableStateOf(vm.prefs.model) }
    var speak by remember { mutableStateOf(vm.prefs.speak) }
    var show by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    var a11y by remember { mutableStateOf(isA11yEnabled(ctx)) }

    val activity = ctx as ComponentActivity
    DisposableEffect(Unit) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) a11y = isA11yEnabled(ctx) }
        activity.lifecycle.addObserver(obs)
        onDispose { activity.lifecycle.removeObserver(obs) }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("SYSTEM CONFIG", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)

        OutlinedTextField(
            value = key, onValueChange = { key = it; saved = false },
            label = { Text("Gemini API key") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            colors = fieldColors()
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = show, onCheckedChange = { show = it }); Text("  Show key", color = TextMain)
        }
        TextButton(onClick = {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        }) { Text("Get a free API key (Google AI Studio)", color = Cyan) }

        OutlinedTextField(
            value = model, onValueChange = { model = it; saved = false },
            label = { Text("Gemini model") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors()
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = speak, onCheckedChange = { speak = it; saved = false }); Text("  RK speaks replies aloud", color = TextMain)
        }
        Button(
            onClick = { vm.prefs.apiKey = key; vm.prefs.model = model; vm.prefs.speak = speak; saved = true },
            colors = ButtonDefaults.buttonColors(containerColor = Cyan), modifier = Modifier.fillMaxWidth()
        ) { Text(if (saved) "SAVED ✓" else "SAVE", color = Bg, fontWeight = FontWeight.Bold) }

        Spacer(Modifier.height(8.dp))
        Text("SCREEN AUTOMATION", color = Cyan, fontSize = 16.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Text(
            "Status: " + if (a11y) "ENABLED" else "DISABLED",
            color = if (a11y) Cyan else Amber
        )
        Text(
            "Optional. Lets RK tap buttons, scroll, go home/back when you say: \"tap Subscribe\", \"scroll down\", \"go back\". " +
                "You turn it on yourself in Android settings and can switch it off anytime.",
            color = CyanDim, fontSize = 13.sp
        )
        OutlinedButton(
            onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
            border = BorderStroke(1.dp, Cyan), modifier = Modifier.fillMaxWidth()
        ) { Text("OPEN ACCESSIBILITY SETTINGS", color = Cyan) }
        Text(
            "If Android says \"Restricted setting\": Settings > Apps > RK AI > ⋮ menu > Allow restricted settings, then try again.",
            color = CyanDim, fontSize = 12.sp
        )
    }
}
