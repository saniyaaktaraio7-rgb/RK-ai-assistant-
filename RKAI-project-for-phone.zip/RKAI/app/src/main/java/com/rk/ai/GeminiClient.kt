package com.rk.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ChatMessage(val fromUser: Boolean, val text: String)

const val RK_PROMPT = "You are RK, a warm, witty and loyal male AI companion with a calm, JARVIS-like personality. " +
    "You talk like a friendly best friend: natural, upbeat, a little humorous, never robotic. " +
    "Your replies are spoken aloud, so keep them short (1-3 sentences), use plain text only, no markdown, no emojis. " +
    "The user can ask you to open apps, play songs on YouTube, and tap or scroll the screen; those are handled by the app, " +
    "so do not pretend to do them yourself. Be honest when you don't know something."

const val CODE_PROMPT = "You are RK Code, an expert senior software engineer and coding assistant. " +
    "Give correct, complete, runnable code in fenced markdown code blocks with the language tag, followed by a brief explanation. " +
    "When debugging, identify the root cause first, then give the fix. Be concise and precise."

object GeminiClient {
    suspend fun chat(apiKey: String, model: String, system: String, history: List<ChatMessage>): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val contents = JSONArray()
                history.forEach { m ->
                    contents.put(
                        JSONObject()
                            .put("role", if (m.fromUser) "user" else "model")
                            .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
                    )
                }
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", contents)

                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 60000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", apiKey)
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code !in 200..299) {
                    val msg = runCatching { JSONObject(raw).getJSONObject("error").getString("message") }.getOrDefault(raw)
                    error("Gemini error $code: $msg")
                }
                val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                val sb = StringBuilder()
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                sb.toString().trim().ifEmpty { "I got an empty response. Try rephrasing?" }
            }
        }
}
