package com.rk.ai

import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.util.Locale

class RkViewModel(app: Application) : AndroidViewModel(app), TextToSpeech.OnInitListener {
    val prefs = Prefs(app)
    val chat = mutableStateListOf<ChatMessage>()
    val code = mutableStateListOf<ChatMessage>()
    var busy by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var statusText by mutableStateOf("ONLINE")

    private var tts: TextToSpeech? = TextToSpeech(app, this)
    private var recognizer: SpeechRecognizer? = null
    private var listenCodeMode = false

    override fun onInit(s: Int) {
        if (s != TextToSpeech.SUCCESS) return
        val t = tts ?: return
        t.language = Locale.US
        t.setPitch(0.78f)
        t.setSpeechRate(0.98f)
        val male = t.voices?.firstOrNull { v ->
            v.locale.language == "en" && !v.isNetworkConnectionRequired &&
                v.name.contains("male", true) && !v.name.contains("female", true)
        }
        if (male != null) t.voice = male
    }

    private fun say(text: String) {
        if (!prefs.speak) return
        val clean = text.replace(Regex("```[\\s\\S]*?```"), " code omitted. ").replace(Regex("[*_`#>]"), "")
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "rk")
    }

    fun send(text: String, codeMode: Boolean = false) {
        val t = text.trim()
        if (t.isEmpty() || busy) return
        val list = if (codeMode) code else chat
        list.add(ChatMessage(true, t))

        if (!codeMode) {
            val handled = try { CommandRouter.handle(getApplication(), t) } catch (e: Exception) { "That command failed: ${e.message}" }
            if (handled != null) {
                list.add(ChatMessage(false, handled))
                say(handled)
                return
            }
        }
        if (prefs.apiKey.isBlank()) {
            val msg = "I need a Gemini API key first. Open the CONFIG tab and paste it in."
            list.add(ChatMessage(false, msg)); say(msg)
            return
        }
        busy = true
        statusText = "PROCESSING"
        val history = list.toList().takeLast(30).dropWhile { !it.fromUser }
        viewModelScope.launch {
            val res = GeminiClient.chat(prefs.apiKey, prefs.model, if (codeMode) CODE_PROMPT else RK_PROMPT, history)
            busy = false
            statusText = "ONLINE"
            val out = res.getOrElse { "Error: ${it.message}" }
            list.add(ChatMessage(false, out))
            if (!codeMode) say(out)
        }
    }

    fun clear(codeMode: Boolean) { if (codeMode) code.clear() else chat.clear() }

    fun startListening(codeMode: Boolean) {
        val app = getApplication<Application>()
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            statusText = "NO SPEECH SERVICE"
            return
        }
        tts?.stop()
        listenCodeMode = codeMode
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(app).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { statusText = "LISTENING" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false; statusText = "ONLINE" }
                override fun onError(error: Int) {
                    listening = false
                    statusText = if (error == 7 || error == 6) "DIDN'T CATCH THAT" else "VOICE ERROR $error"
                }
                override fun onResults(results: Bundle?) {
                    listening = false
                    statusText = "ONLINE"
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!text.isNullOrBlank()) send(text, listenCodeMode)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        listening = true
        recognizer?.startListening(i)
    }

    override fun onCleared() {
        tts?.shutdown()
        recognizer?.destroy()
    }
}
