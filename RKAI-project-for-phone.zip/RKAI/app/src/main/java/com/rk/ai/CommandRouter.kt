package com.rk.ai

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore

/** Handles device commands locally. Returns a reply, or null if Gemini should answer instead. */
object CommandRouter {
    private const val NEED_A11Y = "Please enable the RK AI accessibility service in Settings first, then ask me again."

    fun handle(ctx: Context, raw: String): String? {
        var t = raw.trim().lowercase().trimEnd('.', '!', '?')
        t = t.removePrefix("hey rk").removePrefix("ok rk").removePrefix("rk").trimStart(',', ' ')

        // --- accessibility / system actions ---
        when (t) {
            "go home", "home", "home screen", "go to home screen" -> return a11y { it.home(); "Going home." }
            "go back", "back" -> return a11y { it.back(); "Going back." }
            "recent apps", "recents", "show recent apps" -> return a11y { it.recents(); "Here are your recent apps." }
            "open notifications", "show notifications" -> return a11y { it.notifications(); "Opening notifications." }
            "scroll down" -> return a11y { it.scroll(true); "Scrolling down." }
            "scroll up" -> return a11y { it.scroll(false); "Scrolling up." }
        }
        Regex("^(?:please )?(?:tap|click|press)(?: on)?\\s+(.+)$").find(t)?.let { m ->
            val target = m.groupValues[1].removePrefix("the ").removeSuffix(" button").trim()
            return a11y { svc ->
                if (svc.clickText(target)) "Tapped $target." else "I couldn't find $target on the screen."
            }
        }

        // --- YouTube ---
        Regex("^(?:open youtube\\s+(?:and\\s+)?)?(?:play|put on)\\s+(.+?)(?:\\s+(?:on|in|from)\\s+youtube)?$").find(t)?.let {
            return playOnYouTube(ctx, it.groupValues[1])
        }
        Regex("^(?:search|find|look up)\\s+(.+?)\\s+(?:on|in)\\s+youtube$").find(t)?.let {
            return searchYouTube(ctx, it.groupValues[1], autoplay = false)
        }

        // --- open apps ---
        Regex("^(?:please )?(?:open|launch|start)\\s+(.+)$").find(t)?.let {
            return openApp(ctx, it.groupValues[1])
        }
        return null
    }

    private fun a11y(block: (RkAccessibilityService) -> String): String {
        val svc = RkAccessibilityService.instance ?: return NEED_A11Y
        return block(svc)
    }

    private fun openApp(ctx: Context, nameRaw: String): String {
        val name = nameRaw.removePrefix("the ").removeSuffix(" app").trim()
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val match = apps.firstOrNull { it.first.lowercase() == name }
            ?: apps.firstOrNull { it.first.lowercase().contains(name) }
            ?: apps.firstOrNull { it.first.length > 2 && name.contains(it.first.lowercase()) }
            ?: return "I couldn't find an app called $name."
        val intent = pm.getLaunchIntentForPackage(match.second) ?: return "I can't launch ${match.first}."
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return "Opening ${match.first}."
    }

    private fun playOnYouTube(ctx: Context, query: String): String = searchYouTube(ctx, query, autoplay = true)

    private fun searchYouTube(ctx: Context, query: String, autoplay: Boolean): String {
        val play = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(SearchManager.QUERY, query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            ctx.startActivity(play)
        } catch (e: Exception) {
            val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { ctx.startActivity(web) } catch (e2: Exception) { return "I couldn't open YouTube." }
        }
        if (autoplay) {
            // Best effort: if accessibility is on, tap the first video result after the page loads.
            Handler(Looper.getMainLooper()).postDelayed({
                RkAccessibilityService.instance?.clickFirstDescContaining("play video")
            }, 4500)
        }
        return if (autoplay) "Playing $query on YouTube." else "Searching YouTube for $query."
    }
}
