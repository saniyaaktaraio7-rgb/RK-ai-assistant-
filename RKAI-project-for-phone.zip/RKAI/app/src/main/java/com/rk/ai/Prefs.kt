package com.rk.ai

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("rk_prefs", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sp.getString("api_key", "") ?: ""
        set(v) { sp.edit().putString("api_key", v.trim()).apply() }

    var model: String
        get() = sp.getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) { sp.edit().putString("model", v.trim().ifEmpty { "gemini-2.5-flash" }).apply() }

    var speak: Boolean
        get() = sp.getBoolean("speak", true)
        set(v) { sp.edit().putBoolean("speak", v).apply() }
}
