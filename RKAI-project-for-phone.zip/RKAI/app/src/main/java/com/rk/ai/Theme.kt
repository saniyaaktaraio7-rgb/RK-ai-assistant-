package com.rk.ai

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF030B14)
val Panel = Color(0xFF07141F)
val Cyan = Color(0xFF00E5FF)
val CyanDim = Color(0xFF0A7C8C)
val Amber = Color(0xFFFFB300)
val TextMain = Color(0xFFD6F6FF)

@Composable
fun RkTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan, onPrimary = Bg, background = Bg, surface = Panel,
            onBackground = TextMain, onSurface = TextMain, secondary = Amber
        ),
        content = content
    )
}
